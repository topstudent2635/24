import sqlite3

# Opret forbindelse til SQL databasen
conn = sqlite3.connect('pris_beregner.db')
c = conn.cursor()

# Opret tabel til at gemme kundeoplysninger og projektpriser
c.execute('''CREATE TABLE IF NOT EXISTS projekter (
             id INTEGER PRIMARY KEY,
             navn TEXT NOT NULL,
             email TEXT NOT NULL,
             projekt_navn TEXT NOT NULL,
             krav TEXT NOT NULL,
             stoerrelse TEXT NOT NULL,
             pris REAL NOT NULL,
             status TEXT NOT NULL)''')

# Funktion til at beregne prisen baseret på antal og kompleksitet af krav samt størrelse
def beregn_pris(krav, stoerrelse):
    grundpris = 10000  # Mindste-pris 
    krav_faktor = 1.0 # Starter ved 1.0, neutral multiplikator
    stoerrelse_faktor = 1.0 # Neutral multiplikator

    antal_krav = len(krav.split(','))   # Antal krav indtastet af brugeren

    # Juster krav_faktor baseret på antallet af krav
    if antal_krav > 3:
        krav_faktor += (antal_krav - 3) * 0.2 # Øger faktoren for hvert ekstra krav

    # Juster størrelsesfaktoren for projektet
    if stoerrelse.lower() == "lille":
        stoerrelse_faktor = 1.0
    elif stoerrelse.lower() == "mellem":
        stoerrelse_faktor = 1.5
    elif stoerrelse.lower() == "kompleks":
        stoerrelse_faktor = 2.0
    else:
        raise ValueError("Ugyldig størrelse")

    pris = grundpris * krav_faktor * stoerrelse_faktor  # Beregner den endelige pris
    return pris

# Funktion til at validere input
def validate_input(prompt, valid_options=None):
    while True:
        user_input = input(prompt)
        if user_input.lower() == 'q':  # Tillader brugeren at afslutte programmet
            return None
        if valid_options and user_input.lower() not in valid_options:
            print("Ugyldigt input. Prøv igen.")
        elif not user_input.strip():
            print("Dette felt må ikke være tomt. Indtast og prøv igen.")
        else:
            return user_input

# Funktion til at håndtere prisberegningsprocessen
def prisberegner():
    print("Velkommen til Twentyfour prisberegner. Kom I gang med dit kommende projekt.") 
    while True:
        navn = validate_input("Indtast dit navn ellers tryk 'q' for at afslutte programmet: ")
        if navn is None:
            break

        email = validate_input("Indtast din email: ")
        if email is None:
            break

        projekt_navn = validate_input("Indtast navnet på dit projekt: ")
        if projekt_navn is None:
            break

        krav = validate_input("Indtast dine krav til projektet): ")
        if krav is None:
            break

        stoerrelse = validate_input("Indtast størrelsen på projektet (lille, mellem, kompleks): ", valid_options=['lille', 'mellem', 'kompleks'])
        if stoerrelse is None:
            break

        try:
            pris = beregn_pris(krav, stoerrelse)
            print(f"Den beregnede pris for dit projekt er: {pris:.2f} DKK")

            accept = validate_input("Vil du acceptere tilbuddet? (ja/nej): ", valid_options=['ja', 'nej'])
            if accept is None:
                break

            status = "købt" if accept.lower() == 'ja' else "afvist"
            # Gem kundeoplysninger og pris i databasen
            c.execute("INSERT INTO projekter (navn, email, projekt_navn, krav, stoerrelse, pris, status) VALUES (?, ?, ?, ?, ?, ?, ?)",
                      (navn, email, projekt_navn, krav, stoerrelse, pris, status))
            conn.commit()
            print(f"Dine oplysninger er blevet gemt i databasen med status: {status}")
        except ValueError as e:
            print(e)
            print("Prøv igen.")

# Kør prisberegneren
prisberegner()

# Luk forbindelsen til databasen
conn.close()