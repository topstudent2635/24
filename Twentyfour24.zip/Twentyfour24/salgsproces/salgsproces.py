import sys
import os
from datetime import datetime

# Tilføj den overordnede mappe til sys.path for at kunne finde de andre moduler
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

#Importer de nødvendige klasser fra andre moduler
from database.database_adapter import DatabaseAdapter
from prisberegner.pris import Pris

#Definer klassen Tilbud
class Tilbud: 
    def __init__(self, kunde_navn):  
        self.kunde_navn = kunde_navn   #sætter kunde_navn til instansen kunde_navn
        self.dato = datetime.now().strftime('%d-%m-%Y') #dato
        self.detaljer = []  #Initialiserer en tom liste til at holde detaljer om tilbuddet

#Metode for at tilføje detaljer til tilbuddet
    def tilfoej_detalje(self, beskrivelse, antal_timer, time_pris):
        total_pris = Pris.beregn_total_pris(antal_timer, time_pris)  #Beregner totalprisen baseret på antal timer og timepris
        self.detaljer.append({
            'beskrivelse': beskrivelse,  #Beskrivelse af opgaven
            'antal_timer': antal_timer,  #Antal timer for opgaven
            'time_pris': time_pris,      #Timepris for opgaven   
            'total_pris': total_pris     #Totalpris for opgaven
        })

    #Metode til at beregne totalprisen for alle detaljer i tilbuddet
    def beregn_total_pris(self):
        return sum(d['total_pris'] for d in self.detaljer)  #summen af totalpriserne for alle detaljer

    #Metode til at gemme tilbuddet i databasen
    def gem_tilbud(self, database_adapter, status):
        total_pris = self.beregn_total_pris() #Beregner totalprisen for tilbuddet
        database_adapter.insert_tilbud(self.kunde_navn, total_pris, self.detaljer, status) #Indsætter tilbuddet i databasen

#Validering af brugerens input
def validate_input(prompt, valid_options=None):
    while True:
        user_input = input(prompt) #læser brugerens input
        if user_input.lower() == 'q':  #Hvis brugeren indtaster q, returneres None
            return None
        if valid_options and user_input.lower() not in valid_options: #Hvis input ikke er korrekt, vises en fejlmeddelelse 
            print("Ugyldigt input. Prøv igen.")
        elif not user_input.strip():
            print("Dette felt må ikke være tomt. Prøv igen.")
        else:
            return user_input    #returnerer det korrekte input

#Hovedfunktion til salgsprocessen
def salgsproces():
    db = DatabaseAdapter()  #Initialiserer databaseadapteren
    print("Velkommen til Twentyfour prisberegner. Kom i gang med dit kommende projekt.")

    while True:
        #Læser kundens navn fra inputtet
        kunde_navn = validate_input("Indtast dit navn, ellers indtast 'q' for at afslutte programmet: ")
        if kunde_navn is None: #Hvis brugeren trkker på q, stopper processen.
            break

        tilbud = Tilbud(kunde_navn)     #Opretter et nyt tilbud til kunden, med samme navn.

        while True:
            beskrivelse = validate_input("Indtast beskrivelsen af dit krav: ")
            if beskrivelse is None:
                break
            antal_timer = validate_input("Indtast antal timer: ")
            if antal_timer is None:
                break
            time_pris = validate_input("Indtast timeprisen: ")
            if time_pris is None:
                break

            try:
                antal_timer = int(antal_timer) #Konvetering af antal timer til int
                time_pris = float(time_pris)   #Konvetering af timepris til float
                tilbud.tilfoej_detalje(beskrivelse, antal_timer, time_pris)  #Tilføjer detalje til tilbuddet
            except ValueError:
                print("Indtast venligst gyldige tal for antal timer og timepris.")   #viser fejl hvis input ikke er konveteret
                continue

            tilfoej_mere = validate_input("Vil du tilføje flere detaljer? (ja/nej): ", valid_options=['ja', 'nej'])  #Spærger kunden om flere detaljer
            if tilfoej_mere.lower() == 'nej':   #Hvis nej, så stopper processen
                break

        if len(tilbud.detaljer) > 0:   #Hvis der er tilføjet detaljer til tilbuddet
            total_pris = tilbud.beregn_total_pris() #beregner totalprisen for tilbuddet
            print(f"Den beregnede pris for dit projekt er: {total_pris:.2f} DKK")
            
            accept = validate_input("Vil du acceptere tilbuddet? (ja/nej): ", valid_options=['ja', 'nej'])  #spørger om brugeren vil acceptere tilbuddet
            status = "købt" if accept.lower() == 'ja' else "afvist"
            tilbud.gem_tilbud(db, status)    #gemmer tilbuddet med relevante status
            if accept.lower() == 'ja':
                print("Tilbuddet er blevet gemt i databasen som 'købt'.")
            else:
                print("Tilbuddet er blevet gemt i databasen som 'afvist'.")
        else:
            print("Ingen detaljer tilføjet til tilbuddet.")

#spørger om de vil fortsætte et nyt tilbud
        fortsaet = validate_input("Vil du fortsætte med et nyt tilbud? (ja/nej): ", valid_options=['ja', 'nej'])
        if fortsaet.lower() == 'nej':   #hvis brugeren indtaster nej, aflsuttes processen
            break

if __name__ == "__main__":
    salgsproces()  #salgsprocssen kører