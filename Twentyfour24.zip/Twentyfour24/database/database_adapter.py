import sqlite3
from datetime import datetime #Importerer datetime-modulet til dato- og tidshåndtering
import os #Importerer os-modulet til arbejde med filsystemer

#Definer klassen DatabaseAdapter
class DatabaseAdapter:
    def __init__(self, db_name='24_database.db'):  #Metode til at oprette forbindelse til databasen og tabeller
        self.conn = sqlite3.connect(db_name) #Opretter forbindelsen til databasen
        self.c = self.conn.cursor()  #Opretter cursor til at udføre sql kommandoer
        self.setup_tables()    #Kalder metode for at oprette tabeller

    def setup_tables(self):
        self.c.execute('''CREATE TABLE IF NOT EXISTS projekter (
                            projekt_id INTEGER PRIMARY KEY,
                            kunde_navn TEXT NOT NULL,
                            dato TEXT NOT NULL,
                            total_pris REAL NOT NULL)''')
        
        self.c.execute('''CREATE TABLE IF NOT EXISTS projekt_detajler (
                            detalje_id INTEGER PRIMARY KEY,
                            projekt_id INTEGER,
                            beskrivelse TEXT NOT NULL,
                            antal_timer INTEGER NOT NULL,
                            total_pris REAL NOT NULL,
                            FOREIGN KEY(projekt_id) REFERENCES projekter(projekt_id))''')
        
        self.c.execute('''CREATE TABLE IF NOT EXISTS tilbud (
                            tilbud_id INTEGER PRIMARY KEY,
                            kunde_navn TEXT NOT NULL,
                            dato TEXT NOT NULL,
                            total_pris REAL NOT NULL,
                            status TEXT NOT NULL)''')
        
        self.c.execute('''CREATE TABLE IF NOT EXISTS tilbud_detajler (
                            detalje_id INTEGER PRIMARY KEY,
                            tilbud_id INTEGER,
                            beskrivelse TEXT NOT NULL,
                            antal_timer INTEGER NOT NULL,
                            time_pris REAL NOT NULL,
                            total_pris REAL NOT NULL,
                            FOREIGN KEY(tilbud_id) REFERENCES tilbud(tilbud_id))''')
        self.conn.commit()    #Gemmer ændringen i databasen

#Metode til at indsætte projekt til databasen
    def insert_project(self, kunde_navn, total_pris, detaljer):
        dato = datetime.now().strftime('%d-%m-%Y')
        self.c.execute("INSERT INTO projekter (kunde_navn, dato, total_pris) VALUES (?, ?, ?)",
                       (kunde_navn, dato, total_pris))  #Indsætter projekt i projekter tabellen
        projekt_id = self.c.lastrowid    #Henter id'et på projektet
        for detalje in detaljer:
            #Indsætter detaljer i projekt-detaljer tabellen
            self.c.execute("INSERT INTO projekt_detajler (projekt_id, beskrivelse, antal_timer, total_pris) VALUES (?, ?, ?, ?)",
                           (projekt_id, detalje['beskrivelse'], detalje['antal_timer'], detalje['total_pris']))
        self.conn.commit() #Gemmer ændring i databasen

#Indsætter tilbud i databasen
    def insert_tilbud(self, kunde_navn, total_pris, detaljer, status):
        dato = datetime.now().strftime('%d-%m-%Y')
        self.c.execute("INSERT INTO tilbud (kunde_navn, dato, total_pris, status) VALUES (?, ?, ?, ?)",
                       (kunde_navn, dato, total_pris, status))
        tilbud_id = self.c.lastrowid
        for detalje in detaljer:
            self.c.execute("INSERT INTO tilbud_detajler (tilbud_id, beskrivelse, antal_timer, time_pris, total_pris) VALUES (?, ?, ?, ?, ?)",
                           (tilbud_id, detalje['beskrivelse'], detalje['antal_timer'], detalje['time_pris'], detalje['total_pris']))
        self.conn.commit()

#Metode for at hente alle tilbud fra databasen
    def hent_tilbud(self):
        self.c.execute("SELECT * FROM tilbud")  #Udfører en sql forespørgsel for at hente alle tilbud
        return self.c.fetchall() #returnerer alle rækker fra forespørgslen