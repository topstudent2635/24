class Pris:  #definerer klassen pris
    @staticmethod   #statisk metode for at beregne totalprisen
    def beregn_total_pris(antal_timer, time_pris):  
        return antal_timer * time_pris   #returnerer produktet af antal timer og timepris
    